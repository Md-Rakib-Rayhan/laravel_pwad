<footer class="main-footer">
    <div class="pull-right hidden-xs">Version 1.0</div>
    Copyright © 2018 Yourdomian. All rights reserved.</footer><?php /**PATH C:\xampp\htdocs\laravel-10\laravel_templates\resources\views/backend/layouts/footer.blade.php ENDPATH**/ ?>