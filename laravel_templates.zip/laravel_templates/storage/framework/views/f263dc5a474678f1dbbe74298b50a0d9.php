<!DOCTYPE html>
<html lang="en">
<!-- Head -->
 <?php echo $__env->yieldContent("head"); ?>
<!-- End Head -->
<body class="skin-blue sidebar-mini">
<div class="wrapper boxed-wrapper">
  
<!-- Header -->
 <?php echo $__env->make("backend.layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Header -->


  <!-- Left side column. contains the logo and sidebar -->
<!-- left bar -->
 <?php echo $__env->make("backend.layouts.left_bar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End left bar -->

<!-- Main Contant -->
  <!-- Content Wrapper. Contains page content -->
<?php echo $__env->yieldContent("content"); ?>
  <!-- /.content-wrapper -->
<!-- End Main Contant -->

  <!-- Footer -->
   <?php echo $__env->make("backend.layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Footer -->
  
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark"> 
    <!-- Tab panes -->
    <div class="tab-content"> 
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab"></div>
      <!-- /.tab-pane --> 
    </div>
  </aside>
  <!-- /.control-sidebar --> 
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper --> 

<!-- Script --> 
<?php echo $__env->yieldContent("script"); ?>
<!--End Script-->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-10\laravel_templates\resources\views/backend/layouts/master.blade.php ENDPATH**/ ?>